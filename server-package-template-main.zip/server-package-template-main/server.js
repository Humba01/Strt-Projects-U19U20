/*
 *   Copyright (c) 2020 
 *   All rights reserved.
 */

let http = new XMLHttpRequest();
