# Calculadora Humbanew 

Uma calculadora em PHP melhor que a do mundo real.
