<?php
require_once 'autoload.php';

use Modelo\Service\User;

$interface = new User();
$interface->ui0();
$interface->ui1();
