<?php

namespace Modelo\Model;

class DemonsValorPi
{
    public function fazDemonsValorPi()
    {
        $pi = pi();

        echo "O valor de PI é: $pi";
    }
}
